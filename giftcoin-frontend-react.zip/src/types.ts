export interface VaultItem { name: string; emoji: string; }

export interface Achievements { taps: number; cases: number; refs: number; }

export interface ActiveSubscription { id: 'pro' | 'elite'; clicksLeft: number; clickCount: number; }

export interface ClanState { name: string; logo: string; members: number; rank: number; warTaps: number; }

export interface StarterState { level: number; }

export interface ShadowProfile {
  maxEnergy: number;
  regenPerSec: number;
  energy: number;
  lastEnergyTs: number;
  lastLoginTs: number;
  extraRewardPct: number;
  boosts: Record<string, number>;
  tasksClaimed: string[];
  friendsCountLocal: number; // fallback used before the server referral list loads
}

export interface FriendRow { username: string; balance: number; }
