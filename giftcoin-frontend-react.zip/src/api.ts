import axios, { AxiosError } from 'axios';
import { getInitData } from './telegram';

// FastAPI backend. Cloudflare Pages serves this as a static site with no
// same-origin proxy in front of it (unlike the old Vercel setup, which used
// vercel.json rewrites to make /api/* same-origin), so every request goes
// directly cross-origin to the API. Set VITE_API_URL per environment; the
// fallback below is the production backend so a missing env var still works
// rather than 404ing against a relative path that no longer resolves to anything.
export const API_ROOT = (import.meta.env.VITE_API_URL || 'https://api.richmachine.ru/api/v1').replace(/\/$/, '');
// Base without the /api/v1 suffix, used for non-versioned routes like /avatar.
export const API_BASE = API_ROOT.replace(/\/api\/v1$/, '');

export interface BackendUser {
  id: number;
  telegram_id: number;
  day_limit: number;
  can_win_high_prize: boolean;
  is_active: boolean;
  is_blocked: boolean;
}

export interface BalanceState {
  coins: number;
  stars: number;
}

export interface LeaderboardRow {
  id: number;
  telegram_id?: number;
  name?: string | null;
  first_name?: string | null;
  username?: string | null;
  stars?: number;
  coins?: number;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

const client = axios.create({
  baseURL: API_ROOT,
  headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
});

// Every request re-sends the raw Telegram initData — the backend re-validates
// its HMAC and freshness on every call, so there's no separate login token.
client.interceptors.request.use((config) => {
  const initData = getInitData();
  if (!initData) {
    // Aborting here (instead of letting the request go out without the
    // header) keeps the "open outside Telegram -> demo mode" behaviour
    // that the rest of the app relies on, without a real network round-trip.
    return Promise.reject(new ApiError('Telegram initData отсутствует. Открой приложение внутри Telegram.', 0));
  }
  config.headers = config.headers ?? {};
  config.headers['X-Telegram-Init-Data'] = initData;
  return config;
});

client.interceptors.response.use(
  (res) => res,
  (error: AxiosError<{ detail?: string }>) => {
    if (error instanceof ApiError) return Promise.reject(error);
    const status = error.response?.status ?? 0;
    const detail = error.response?.data?.detail ?? error.message;
    return Promise.reject(new ApiError(`API ${error.config?.url}: ${status} ${detail}`, status));
  },
);

export const api = {
  auth: () => client.post<BackendUser>('/users/auth').then((r) => r.data),
  balance: () => client.get<BalanceState>('/balance/').then((r) => r.data),
  click: () => client.post<{ coin_added: number; prize: number | null }>('/click/').then((r) => r.data),
  leaderboard: () => client.get<LeaderboardRow[]>('/rating/').then((r) => r.data),
  health: () => client.get<boolean>('/utils/health-check/').then((r) => r.data),
};
