import { useCallback, useRef } from 'react';
import { api } from '../api';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { haptic } from '../telegram';
import { subCfg } from '../data/constants';

// The current backend only exposes one click per POST /click/ (no batching
// endpoint yet — see README "Important limitations"), so every tap still
// means one background request. To keep the tap itself feeling instant we
// update the local energy/coin display immediately and fire the network
// call without blocking the UI, queuing calls so a burst of taps doesn't
// open dozens of parallel connections. Server balance is periodically
// reconciled via refreshBalance() to correct for any dropped requests.
const MAX_INFLIGHT = 3;

export function useTap() {
  const inflightRef = useRef(0);
  const queueRef = useRef(0);

  const drain = useCallback(async () => {
    while (queueRef.current > 0 && inflightRef.current < MAX_INFLIGHT) {
      queueRef.current -= 1;
      inflightRef.current += 1;
      api.click()
        .then((r) => {
          // coin_added is already reflected optimistically; only true-up
          // if the server disagrees (e.g. day_limit hit) and surface prizes.
          if (r.prize) {
            useLocalStore.getState().addVaultItem({ name: `Подарок ⭐️${r.prize}`, emoji: '⭐️' });
          }
        })
        .catch(() => {
          // network/limit failure — pull the coin back out of the optimistic
          // balance so it doesn't drift from what the server actually holds.
          useAuthStore.getState().applyCoinDelta(-1);
        })
        .finally(() => {
          inflightRef.current -= 1;
          if (queueRef.current > 0) drain();
        });
    }
  }, []);

  const tap = useCallback((): { ok: boolean; amount: number } => {
    const local = useLocalStore.getState();
    const sub = local.subscription;

    if (sub) {
      if (sub.clicksLeft <= 0) return { ok: false, amount: 0 };
      haptic('light');
      local.subscriptionTap();
      useAuthStore.getState().applyCoinDelta(1);
      if (sub.clickCount > 0 && sub.clickCount % 50 === 0) {
        const cfg = subCfg(sub.id);
        if (Math.random() < cfg.giftChance) {
          const giftValue = 1 + Math.floor(Math.random() * cfg.maxGift);
          local.addVaultItem({ name: `Подарок ⭐️${giftValue}`, emoji: '⭐️' });
        }
      }
      // Subscription clicks are a local-only economy layer on top of the
      // real balance today (no matching backend concept yet), so they
      // don't hit /click/ — same shadow-state caveat as cases/wheel/quiz.
      return { ok: true, amount: 1 };
    }

    local.recomputeEnergy();
    if (local.profile.energy <= 0) return { ok: false, amount: 0 };
    haptic('light');
    local.spendEnergy(1);
    useAuthStore.getState().applyCoinDelta(1);
    queueRef.current += 1;
    drain();
    return { ok: true, amount: 1 };
  }, [drain]);

  return { tap };
}
