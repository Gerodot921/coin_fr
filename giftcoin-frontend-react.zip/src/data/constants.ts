// Ported 1:1 from gift-coin-front.html so behaviour/economy stays identical
// while the UI moves to React. Anything not yet backed by a FastAPI endpoint
// stays client-side ("shadow" state) exactly like it did in the old file —
// see README.md for the current backend contract.

export const BOT_USERNAME = import.meta.env.VITE_BOT_USERNAME || 'GlFT_Coin_bot';

export const PROFILE_MAX_ENERGY = 100000;

export const RANKS = [
  { name: 'Bronze', from: 0 },
  { name: 'Silver', from: 10000 },
  { name: 'Gold', from: 100000 },
  { name: 'Platinum', from: 1000000 },
  { name: 'Diamond', from: 10000000 },
];

export function rankFor(b: number) {
  let i = 0;
  for (let k = 0; k < RANKS.length; k++) if (b >= RANKS[k].from) i = k;
  const cur = RANKS[i];
  const next = RANKS[i + 1];
  return {
    rank: cur.name,
    rankCurrent: b - cur.from,
    rankNext: next ? next.from - cur.from : cur.from,
    level: i + 1 + Math.floor(Math.log10(Math.max(1, b - cur.from) + 1)),
  };
}

export interface CaseDef { id: string; name: string; price: number; emoji: string; desc: string; }
export const CASES: CaseDef[] = [
  { id: 'basic', name: 'Базовый', price: 500000, emoji: '📦', desc: 'Обычный кейс' },
  { id: 'premium', name: 'Премиум', price: 2500000, emoji: '🎁', desc: 'Улучшенный кейс' },
  { id: 'legend', name: 'Легендарный', price: 10000000, emoji: '👑', desc: 'Редкий кейс' },
];

export interface StarterLevel { level: number; price: number; requireFriends?: number; }
export const STARTER_LEVELS: StarterLevel[] = [
  { level: 1, price: 50000, requireFriends: 2 },
  { level: 2, price: 75000 },
  { level: 3, price: 100000 },
  { level: 4, price: 125000 },
  { level: 5, price: 150000 },
];

export interface SubscriptionDef {
  id: 'pro' | 'elite'; name: string; short: string; color: string;
  price: number; clicks: number; maxGift: number; giftChance: number;
  desc: string; features: string[];
}
export const SUBSCRIPTIONS: SubscriptionDef[] = [
  {
    id: 'pro', name: 'GIFT COIN PRO', short: 'PRO', color: '#22c55e',
    price: 0, clicks: 10000, maxGift: 500, giftChance: 0.001,
    desc: 'Больше возможностей. Больше попыток. Больше шансов.',
    features: [
      '10 000 бонусных кликов',
      '∞ Безлимитная энергия — играй без ожидания восстановления',
      '+1 GC за каждый клик',
      'Повышенный шанс на получение подарка 🎁',
      'Доступ к подаркам до 500 ⭐',
      'VIP-задания с повышенной наградой',
      'Приоритетный вывод',
    ],
  },
  {
    id: 'elite', name: 'GIFT COIN ELITE', short: 'ELITE', color: '#facc15',
    price: 0, clicks: 10000, maxGift: 10000, giftChance: 0.0025,
    desc: 'Максимум возможностей для охоты за редкими подарками',
    features: [
      '10 000 бонусных кликов',
      '∞ Безлимитная энергия — играй без ограничений',
      '+1 GC за каждый клик',
      'Максимально высокий шанс на получение подарка 🎁',
      '🔒 Доступ к эксклюзивному пулу редких подарков',
      '💎 Редкие подарки стоимостью до 10 000 ⭐',
      'Эксклюзивные VIP-задания с высокой наградой',
      'Мгновенный вывод без очереди',
    ],
  },
];
export const subCfg = (id: string) => SUBSCRIPTIONS.find((s) => s.id === id)!;

export interface BoostDef { id: string; name: string; desc: string; baseCost: number; icon: string; }
export const BOOSTS: BoostDef[] = [
  { id: 'multitap', name: 'Multitap', desc: '+3 за тап', baseCost: 500, icon: 'zap' },
  { id: 'regen', name: 'Скорость регена', desc: '+25% скорость', baseCost: 750, icon: 'gauge' },
  { id: 'offline', name: 'Оффлайн заработок', desc: '+100/час', baseCost: 1500, icon: 'moon' },
  { id: 'extra', name: 'Бонус заданий', desc: '+10% награды', baseCost: 1250, icon: 'star' },
];
export const boostCost = (b: BoostDef, lvl: number) => Math.floor(b.baseCost * Math.pow(1.6, lvl));

export const QUIZ = [
  { q: 'Какой блокчейн использует GIFT COIN?', opts: ['Ethereum', 'TON', 'Solana', 'Bitcoin'], a: 1 },
  { q: 'Что такое Telegram Stars?', opts: ['Криптовалюта', 'Внутренняя валюта Telegram', 'NFT', 'Стейблкоин'], a: 1 },
  { q: 'Сколько уровней реферальной системы?', opts: ['1', '2', '3', '5'], a: 2 },
];

export const WHEEL_SEGMENTS = ['100K', '⭐', '500K', '💎', '50K', '👑', '200K', '🎁'];
export const WHEEL_REWARDS = [100000, 500000, 50000, 200000, 250000, 1000000, 75000, 300000];

export interface TaskDef {
  id: string; title: string; reward: number; kind: 'daily' | 'once';
  action: 'claim' | 'link' | 'video' | 'progress'; meta?: string;
}
export const DAILY_TASKS: TaskDef[] = [
  { id: 'daily_login', title: 'Ежедневный вход', reward: 100000, kind: 'daily', action: 'claim' },
  { id: 'tap_1000', title: 'Натапай 1000 раз', reward: 50000, kind: 'daily', action: 'progress' },
  { id: 'daily_reward', title: 'Собери ежедневную награду', reward: 75000, kind: 'daily', action: 'claim' },
];
export const PROJECT_TASKS: TaskDef[] = [
  { id: 'join_tg', title: 'Подпишись на канал проекта', reward: 50000, kind: 'once', action: 'link', meta: 't.me/GiftCoinNews' },
  { id: 'follow_x', title: 'Подпишись в X', reward: 50000, kind: 'once', action: 'link', meta: 'x.com/' },
];
export const AD_TASKS: TaskDef[] = [
  { id: 'watch_video', title: 'Посмотри рекламное видео', reward: 30000, kind: 'once', action: 'video' },
  { id: 'partner_app', title: 'Установи партнёрское приложение', reward: 150000, kind: 'once', action: 'link', meta: '#' },
  { id: 'survey', title: 'Пройди опрос рекламодателя', reward: 80000, kind: 'once', action: 'claim' },
];

export const SHOP_PACKS = [
  { id: 'pack1', name: 'Стартовый', amount: 1500000, price: '1 000 ₽' },
  { id: 'pack2', name: 'Про', amount: 13000000, price: '5 000 ₽' },
  { id: 'silver', name: 'Silver Pack', amount: 100000, price: '$1.99' },
  { id: 'gold', name: 'Gold Pack', amount: 550000, price: '$4.99' },
];

export const fmt = (n: number) => Math.floor(n).toLocaleString('ru-RU');
