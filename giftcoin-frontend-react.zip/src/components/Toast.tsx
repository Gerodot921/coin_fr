import { useEffect, useState } from 'react';
import { create } from 'zustand';

interface ToastState { msg: string; show: boolean; fire: (msg: string) => void; }

let timer: ReturnType<typeof setTimeout> | undefined;
export const useToast = create<ToastState>((set) => ({
  msg: '',
  show: false,
  fire: (msg) => {
    set({ msg, show: true });
    clearTimeout(timer);
    timer = setTimeout(() => set({ show: false }), 2000);
  },
}));

export function toast(msg: string) {
  useToast.getState().fire(msg);
}

export function Toast() {
  const { msg, show } = useToast();
  const [render, setRender] = useState(false);
  useEffect(() => {
    if (show) setRender(true);
  }, [show]);
  if (!render) return null;
  return (
    <div id="toast" className={show ? 'show' : ''}>{msg}</div>
  );
}
