import { useState } from 'react';
import { Icon } from './Icons';
import { useNav } from '../store/useNav';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { subCfg } from '../data/constants';
import { API_BASE } from '../api';
import { avatarUrl } from '../telegram';

export function Header({ title, mode = 'avatar' }: { title: string; mode?: 'avatar' | 'back' | 'none' }) {
  const back = useNav((s) => s.back);
  const go = useNav((s) => s.go);
  const user = useAuthStore((s) => s.user);
  const sub = useLocalStore((s) => s.subscription);
  const [avatarFailed, setAvatarFailed] = useState(false);

  let left;
  if (mode === 'back') {
    left = (
      <div className="side back" style={{ borderRadius: 12, width: 36, height: 36 }} onClick={back}>
        <Icon name="back" />
      </div>
    );
  } else if (mode === 'none') {
    left = <div className="side" />;
  } else {
    left = (
      <>
        <div className="ava" onClick={() => go('profile')}>
          {user && !avatarFailed ? (
            <img
              className="ava-img"
              src={avatarUrl(API_BASE, user.telegramId)}
              alt="avatar"
              referrerPolicy="no-referrer"
              onError={() => setAvatarFailed(true)}
            />
          ) : (
            <Icon name="user" />
          )}
        </div>
        {sub && (
          <div className="side" style={{ color: subCfg(sub.id).color, cursor: 'pointer' }} onClick={() => go('subscription')}>
            <Icon name="crown" />
          </div>
        )}
      </>
    );
  }

  return (
    <div className="hd glass">
      {left}
      <div className="ttl">{title}</div>
      <div className="side" />
    </div>
  );
}
