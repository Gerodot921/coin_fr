import { Icon } from './Icons';
import { Screen, useNav } from '../store/useNav';

const ITEMS: { id: Screen; label: string; icon: string }[] = [
  { id: 'earn', label: 'Тап', icon: 'gift' },
  { id: 'games', label: 'Игры', icon: 'game' },
  { id: 'cases', label: 'Кейсы', icon: 'box' },
  { id: 'tasks', label: 'Задания', icon: 'clip' },
  { id: 'profile', label: 'Профиль', icon: 'user' },
];

export function BottomNav() {
  const tab = useNav((s) => s.tab);
  const go = useNav((s) => s.go);
  return (
    <nav className="nav glass">
      {ITEMS.map((item) => (
        <button key={item.id} className={tab === item.id ? 'on' : ''} onClick={() => go(item.id)}>
          <span className="gi"><Icon name={item.icon} /></span>
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
