import WebApp from '@twa-dev/sdk';

export function initTelegram() {
  try {
    WebApp.ready();
    WebApp.expand();
    WebApp.setHeaderColor('#000000' as any);
    WebApp.setBackgroundColor('#000000' as any);
  } catch {
    // Local browser fallback — running outside Telegram.
  }
}

export function getInitData(): string {
  try {
    return WebApp.initData || '';
  } catch {
    return '';
  }
}

export function tgUser(): { id: number; username?: string; photo_url?: string } | null {
  try {
    return (WebApp.initDataUnsafe && (WebApp.initDataUnsafe as any).user) || null;
  } catch {
    return null;
  }
}

// Referral id must travel inside the signed initData (`start_param`), which
// Telegram only fills in for t.me/<bot>?startapp=<id> links — a hand-built
// `?ref=` query string on a plain web_app button URL is not authenticated,
// so the backend can't trust it. See project notes (Этап 2).
export function getStartParam(): string | undefined {
  try {
    const fromTelegram = (WebApp.initDataUnsafe as any)?.start_param;
    if (fromTelegram) return fromTelegram;
  } catch {
    // noop
  }
  return new URLSearchParams(window.location.search).get('ref') || undefined;
}

export function getBotUsername(): string | undefined {
  return import.meta.env.VITE_BOT_USERNAME || undefined;
}

export function haptic(kind: 'light' | 'success' | 'error' | 'warning' = 'light') {
  try {
    if (kind === 'success' || kind === 'error' || kind === 'warning') {
      WebApp.HapticFeedback.notificationOccurred(kind);
    } else {
      WebApp.HapticFeedback.impactOccurred('light');
    }
  } catch {
    // noop outside Telegram
  }
}

export function showAlert(message: string) {
  try {
    WebApp.showAlert(message);
  } catch {
    window.alert(message);
  }
}

export function openTelegramLink(url: string) {
  try {
    WebApp.openTelegramLink(url);
  } catch {
    window.open(url, '_blank');
  }
}

export function avatarUrl(apiBase: string, telegramId: number | string): string {
  return `${apiBase}/avatar/${encodeURIComponent(String(telegramId))}`;
}
