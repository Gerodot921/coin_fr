import { create } from 'zustand';

export type Screen =
  | 'earn' | 'games' | 'cases' | 'tasks' | 'profile'
  | 'shop' | 'subscription' | 'boost' | 'friends' | 'clans'
  | 'vault' | 'upgrader' | 'wheel' | 'quiz' | 'leaderboard'
  | 'achievements' | 'stats' | 'staking' | 'daily';

export const ROOT_TABS: Screen[] = ['earn', 'games', 'cases', 'tasks', 'profile'];

// Which root tab should highlight as "active" while a sub-screen is open.
const SCREEN_TO_TAB: Partial<Record<Screen, Screen>> = {
  shop: 'profile', subscription: 'profile', boost: 'profile', friends: 'profile',
  clans: 'profile', stats: 'profile', staking: 'profile', achievements: 'tasks',
  vault: 'cases', upgrader: 'games', wheel: 'games', quiz: 'games', leaderboard: 'games',
  daily: 'earn',
};

interface NavState {
  screen: Screen;
  tab: Screen;
  go: (screen: Screen) => void;
  back: () => void;
}

export const useNav = create<NavState>((set, get) => ({
  screen: 'earn',
  tab: 'earn',
  go: (screen) => {
    const tab = ROOT_TABS.includes(screen) ? screen : SCREEN_TO_TAB[screen] || get().tab;
    set({ screen, tab });
  },
  back: () => set({ screen: get().tab }),
}));
