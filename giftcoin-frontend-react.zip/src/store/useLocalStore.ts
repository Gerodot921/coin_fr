import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { PROFILE_MAX_ENERGY } from '../data/constants';
import type { Achievements, ActiveSubscription, ClanState, FriendRow, ShadowProfile, StarterState, VaultItem } from '../types';

function freshProfile(): ShadowProfile {
  return {
    maxEnergy: PROFILE_MAX_ENERGY,
    regenPerSec: +(PROFILE_MAX_ENERGY / 86400).toFixed(4),
    energy: PROFILE_MAX_ENERGY,
    lastEnergyTs: Date.now(),
    lastLoginTs: 0,
    extraRewardPct: 0,
    boosts: {},
    tasksClaimed: [],
    friendsCountLocal: 0,
  };
}

interface LocalState {
  profile: ShadowProfile;
  vault: VaultItem[];
  achievements: Achievements;
  subscription: ActiveSubscription | null;
  clan: ClanState | null;
  totalTaps: number;
  starter: StarterState;
  starterFriendGatePassed: boolean;
  wheelLast: number;
  friends: FriendRow[];

  recomputeEnergy: () => void;
  spendEnergy: (n: number) => void;
  gainCoinsLocalTaps: (n: number) => void;
  addVaultItem: (item: VaultItem) => void;
  incCases: () => void;
  incRefs: () => void;
  setSubscription: (s: ActiveSubscription | null) => void;
  subscriptionTap: () => void;
  setClan: (c: ClanState | null) => void;
  claimTask: (id: string) => void;
  claimDailyLogin: () => void;
  bumpStarter: () => void;
  passStarterGate: () => void;
  spinWheel: () => void;
  setFriends: (f: FriendRow[]) => void;
}

export const useLocalStore = create<LocalState>()(
  persist(
    (set, get) => ({
      profile: freshProfile(),
      vault: [{ name: '50 Stars', emoji: '⭐' }],
      achievements: { taps: 0, cases: 0, refs: 0 },
      subscription: null,
      clan: null,
      totalTaps: 0,
      starter: { level: 1 },
      starterFriendGatePassed: false,
      wheelLast: 0,
      friends: [],

      recomputeEnergy: () => {
        const p = get().profile;
        const now = Date.now();
        const seconds = Math.max(0, (now - p.lastEnergyTs) / 1000);
        const gained = Math.floor(seconds * p.regenPerSec);
        if (gained > 0) {
          set({
            profile: {
              ...p,
              energy: Math.min(p.maxEnergy, p.energy + gained),
              lastEnergyTs: now,
            },
          });
        }
      },

      spendEnergy: (n) => {
        const p = get().profile;
        set({
          profile: { ...p, energy: Math.max(0, p.energy - n), lastEnergyTs: Date.now() },
          totalTaps: get().totalTaps + n,
          achievements: { ...get().achievements, taps: get().achievements.taps + n },
        });
      },

      gainCoinsLocalTaps: (n) => {
        set({
          totalTaps: get().totalTaps + n,
          achievements: { ...get().achievements, taps: get().achievements.taps + n },
        });
      },

      addVaultItem: (item) => set({ vault: [...get().vault, item] }),
      incCases: () => set({ achievements: { ...get().achievements, cases: get().achievements.cases + 1 } }),
      incRefs: () => set({ achievements: { ...get().achievements, refs: get().achievements.refs + 1 } }),

      setSubscription: (s) => set({ subscription: s }),
      subscriptionTap: () => {
        const sub = get().subscription;
        if (!sub || sub.clicksLeft <= 0) return;
        const next = { ...sub, clicksLeft: sub.clicksLeft - 1, clickCount: sub.clickCount + 1 };
        set({
          subscription: next.clicksLeft <= 0 ? null : next,
          totalTaps: get().totalTaps + 1,
          achievements: { ...get().achievements, taps: get().achievements.taps + 1 },
        });
      },

      setClan: (c) => set({ clan: c }),

      claimTask: (id) => {
        const p = get().profile;
        if (p.tasksClaimed.includes(id)) return;
        set({ profile: { ...p, tasksClaimed: [...p.tasksClaimed, id] } });
      },
      claimDailyLogin: () => set({ profile: { ...get().profile, lastLoginTs: Date.now() } }),

      bumpStarter: () => {
        const lvl = get().starter.level;
        set({ starter: { level: lvl >= 5 ? 1 : lvl + 1 } });
      },
      passStarterGate: () => set({ starterFriendGatePassed: true }),

      spinWheel: () => set({ wheelLast: Date.now() }),

      setFriends: (f) => set({ friends: f }),
    }),
    { name: 'gc_local_v2' },
  ),
);
