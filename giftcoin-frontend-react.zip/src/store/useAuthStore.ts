import { create } from 'zustand';
import { api, ApiError, BackendUser } from '../api';
import { tgUser } from '../telegram';
import { rankFor } from '../data/constants';

export interface GameUser {
  id: number;
  telegramId: number;
  username: string;
  balance: number;
  stars: number;
  rank: string;
  level: number;
  rankCurrent: number;
  rankNext: number;
  isBlocked: boolean;
}

function buildUser(backend: BackendUser, coins: number, stars: number): GameUser {
  const tg = tgUser();
  return {
    id: backend.id,
    telegramId: backend.telegram_id,
    username: (tg && tg.username) || `user${backend.telegram_id}`,
    balance: coins,
    stars,
    isBlocked: backend.is_blocked || !backend.is_active,
    ...rankFor(coins),
  };
}

interface AuthState {
  user: GameUser | null;
  loading: boolean;
  error: string | null;
  demo: boolean;
  init: () => Promise<void>;
  refreshBalance: () => Promise<void>;
  applyCoinDelta: (coinAdded: number) => void;
  clearError: () => void;
}

function demoUser(): GameUser {
  return {
    id: 0, telegramId: 0, username: 'player', balance: 1250000, stars: 0,
    isBlocked: false, ...rankFor(1250000),
  };
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  loading: true,
  error: null,
  demo: false,

  init: async () => {
    set({ loading: true, error: null });
    try {
      const backendUser = await api.auth();
      if (backendUser.is_blocked || !backendUser.is_active) {
        throw new Error('Профиль заблокирован или деактивирован.');
      }
      const balance = await api.balance();
      set({ user: buildUser(backendUser, balance.coins, balance.stars), loading: false, demo: false });
    } catch (e) {
      // No initData at all (opened outside Telegram) → fall back to a demo
      // profile so the UI is still browsable, same as the old front did —
      // but always surface a visible warning, never silently pretend it's real.
      if (e instanceof ApiError && e.status === 0) {
        set({ user: demoUser(), loading: false, demo: true, error: null });
        return;
      }
      set({ error: e instanceof Error ? e.message : 'Ошибка загрузки', loading: false });
    }
  },

  refreshBalance: async () => {
    if (get().demo) return;
    try {
      const balance = await api.balance();
      const u = get().user;
      if (!u) return;
      set({ user: { ...u, balance: balance.coins, stars: balance.stars, ...rankFor(balance.coins) } });
    } catch {
      // transient — keep the last known balance, next flush will retry
    }
  },

  applyCoinDelta: (coinAdded) => {
    const u = get().user;
    if (!u) return;
    const balance = u.balance + coinAdded;
    set({ user: { ...u, balance, ...rankFor(balance) } });
  },

  clearError: () => set({ error: null }),
}));
