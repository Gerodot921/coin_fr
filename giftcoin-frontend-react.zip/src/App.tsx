import { useEffect } from 'react';
import { useAuthStore } from './store/useAuthStore';
import { useNav } from './store/useNav';
import { initTelegram } from './telegram';
import { IconSprite } from './components/Icons';
import { BottomNav } from './components/BottomNav';
import { Toast } from './components/Toast';

import { EarnScreen } from './screens/EarnScreen';
import { GamesHubScreen } from './screens/GamesHubScreen';
import { UpgraderScreen } from './screens/UpgraderScreen';
import { WheelScreen } from './screens/WheelScreen';
import { QuizScreen } from './screens/QuizScreen';
import { LeaderboardScreen } from './screens/LeaderboardScreen';
import { CasesScreen } from './screens/CasesScreen';
import { VaultScreen } from './screens/VaultScreen';
import { TasksScreen } from './screens/TasksScreen';
import { AchievementsScreen } from './screens/AchievementsScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { ShopScreen } from './screens/ShopScreen';
import { SubscriptionScreen } from './screens/SubscriptionScreen';
import { BoostScreen } from './screens/BoostScreen';
import { FriendsScreen } from './screens/FriendsScreen';
import { ClansScreen } from './screens/ClansScreen';
import { StatsScreen } from './screens/StatsScreen';
import { StakingScreen } from './screens/StakingScreen';
import { DailyScreen } from './screens/DailyScreen';

const SCREENS: Record<string, () => JSX.Element | null> = {
  earn: EarnScreen,
  games: GamesHubScreen,
  upgrader: UpgraderScreen,
  wheel: WheelScreen,
  quiz: QuizScreen,
  leaderboard: LeaderboardScreen,
  cases: CasesScreen,
  vault: VaultScreen,
  tasks: TasksScreen,
  achievements: AchievementsScreen,
  profile: ProfileScreen,
  shop: ShopScreen,
  subscription: SubscriptionScreen,
  boost: BoostScreen,
  friends: FriendsScreen,
  clans: ClansScreen,
  stats: StatsScreen,
  staking: StakingScreen,
  daily: DailyScreen,
};

export default function App() {
  const { user, loading, error, demo, init, clearError } = useAuthStore();
  const screen = useNav((s) => s.screen);

  useEffect(() => {
    initTelegram();
    init();
  }, [init]);

  if (loading) {
    return (
      <div id="app">
        <IconSprite />
        <div className="load">Загрузка…</div>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div id="app">
        <IconSprite />
        <div className="load">
          Не удалось загрузить профиль.<br />
          Открой приложение через Telegram.
          {error && <div className="mut" style={{ marginTop: 10, fontSize: 11 }}>{error}</div>}
          <button className="full w" style={{ marginTop: 16 }} onClick={() => { clearError(); init(); }}>Повторить</button>
        </div>
      </div>
    );
  }

  const Screen = SCREENS[screen] || EarnScreen;

  return (
    <div id="app">
      <IconSprite />
      {demo && <div className="demo-flag">Demo режим — backend недоступен</div>}
      <Screen />
      <BottomNav />
      <Toast />
    </div>
  );
}
