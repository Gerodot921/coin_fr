import { useEffect, useRef, useState } from 'react';
import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { useNav } from '../store/useNav';
import { useTap } from '../hooks/useTap';
import { fmt, subCfg, SUBSCRIPTIONS } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

interface Floater { id: number; x: number; y: number; }

function promoBanner(sub: ReturnType<typeof useLocalStore.getState>['subscription'], go: (s: any) => void) {
  if (sub && sub.id === 'elite') return null;
  const idx = sub && sub.id === 'pro' ? 1 : 0;
  const s = SUBSCRIPTIONS[idx];
  return (
    <div className="promo-banner" style={{ ['--pc' as any]: s.color }} onClick={() => go('subscription')}>
      <div className="pb-ico"><Icon name="crown" /></div>
      <h4>{s.name}</h4>
      <p>{s.desc}</p>
      <span className="pb-btn">Попробуй</span>
    </div>
  );
}

export function EarnScreen() {
  const user = useAuthStore((s) => s.user);
  const go = useNav((s) => s.go);
  const profile = useLocalStore((s) => s.profile);
  const sub = useLocalStore((s) => s.subscription);
  const recomputeEnergy = useLocalStore((s) => s.recomputeEnergy);
  const { tap } = useTap();
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const [flash, setFlash] = useState(false);
  const [pop, setPop] = useState(false);
  const [, forceTick] = useState(0);
  const idRef = useRef(0);

  useEffect(() => {
    recomputeEnergy();
    const t = setInterval(() => { recomputeEnergy(); forceTick((n) => n + 1); }, 1000);
    return () => clearInterval(t);
  }, [recomputeEnergy]);

  if (!user) return null;
  const scfg = sub && subCfg(sub.id);
  const pct = sub && scfg ? Math.round((sub.clicksLeft / scfg.clicks) * 100) : Math.round((profile.energy / profile.maxEnergy) * 100);

  function onTap(ev: React.MouseEvent<HTMLDivElement>) {
    const result = tap();
    if (!result.ok) {
      haptic('error');
      toast(sub ? 'Клики подписки закончились' : 'Энергия закончилась');
      return;
    }
    const rect = (ev.currentTarget.parentElement as HTMLElement).getBoundingClientRect();
    const id = idRef.current++;
    setFloaters((f) => [...f, { id, x: ev.clientX - rect.left, y: ev.clientY - rect.top }]);
    setTimeout(() => setFloaters((f) => f.filter((x) => x.id !== id)), 750);
    setFlash(false); requestAnimationFrame(() => setFlash(true));
  }

  function energyTimer() {
    const remainRegen = profile.regenPerSec || profile.maxEnergy / 86400;
    const elapsed = Math.max(0, (Date.now() - profile.lastEnergyTs) / 1000);
    const cur = Math.min(profile.maxEnergy, profile.energy + elapsed * remainRegen);
    const remainingSec = Math.max(0, (profile.maxEnergy - cur) / remainRegen);
    if (remainingSec <= 0.5) return 'Полная ⚡';
    const h = Math.floor(remainingSec / 3600);
    const m = Math.floor((remainingSec % 3600) / 60);
    const s = Math.floor(remainingSec % 60);
    return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
  }

  return (
    <>
      <Header title="GIFT COIN" mode="avatar" />
      <div className="sc">
        <div className="bal">
          <div className="v num">{fmt(user.balance)}</div>
          <div className="u">GIFT COIN</div>
          <div className="pt">{sub ? `+1 за тап · подписка ${scfg!.short}` : '+1 за тап'}</div>
        </div>
        <div className={`coinwrap ${flash ? 'flash' : ''}`}>
          <div className="coin glass" onPointerDown={onTap}>
            <Icon name="gift" />
          </div>
          {floaters.map((f) => (
            <span key={f.id} className="float" style={{ left: f.x, top: f.y }}>+1</span>
          ))}
        </div>
        <div className="card glass pad" style={{ cursor: 'pointer' }} onClick={() => setPop((p) => !p)}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--mut)', marginBottom: 6 }}>
            <span><Icon name="zap" /> {sub ? 'Клики подписки' : 'Энергия'}</span>
            <span className="num">{sub ? `${fmt(sub.clicksLeft)} / ${fmt(scfg!.clicks)}` : `${fmt(profile.energy)} / ${fmt(profile.maxEnergy)}`}</span>
          </div>
          <div className="bar"><i style={{ width: `${pct}%` }} /></div>
        </div>
        {!sub && (
          <div className={`energy-pop ${pop ? 'open' : ''}`}>
            <div className="energy-pop-in">
              <small>Полное восстановление через</small>
              <b>{energyTimer()}</b>
            </div>
          </div>
        )}
        <div className="two" style={{ marginTop: 10 }}>
          <div className="card glass" onClick={() => go('daily')}><small>Ежедневная</small><b><Icon name="star" /></b></div>
          <div className="card glass" onClick={() => go('leaderboard')}><small>Рейтинг</small><b><Icon name="trophy" /></b></div>
        </div>
        {promoBanner(sub, go)}
      </div>
    </>
  );
}
