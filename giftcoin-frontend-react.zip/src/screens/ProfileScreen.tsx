import { useState } from 'react';
import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useNav, Screen } from '../store/useNav';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { fmt, subCfg } from '../data/constants';
import { API_BASE } from '../api';
import { avatarUrl } from '../telegram';
import { toast } from '../components/Toast';

const MENU: { icon: string; title: string; to: Screen | null }[] = [
  { icon: 'store', title: 'Магазин коинов', to: 'shop' },
  { icon: 'crown', title: 'Подписки', to: 'subscription' },
  { icon: 'zap', title: 'Бустеры', to: 'boost' },
  { icon: 'share', title: 'Рефералы', to: 'friends' },
  { icon: 'sword', title: 'Кланы', to: 'clans' },
  { icon: 'chart', title: 'Статистика', to: 'stats' },
  { icon: 'vault', title: 'Стейкинг', to: 'staking' },
  { icon: 'cog', title: 'Настройки', to: null },
];

export function ProfileScreen() {
  const go = useNav((s) => s.go);
  const user = useAuthStore((s) => s.user);
  const achievements = useLocalStore((s) => s.achievements);
  const friendsCountLocal = useLocalStore((s) => s.profile.friendsCountLocal);
  const sub = useLocalStore((s) => s.subscription);
  const [avatarFailed, setAvatarFailed] = useState(false);

  if (!user) return null;
  const pct = Math.min(100, Math.round((user.rankCurrent / Math.max(1, user.rankNext)) * 100));

  return (
    <>
      <Header title="ПРОФИЛЬ" mode="none" />
      <div className="sc">
        <div className="card glass row">
          <div className="bx" style={{ width: 48, height: 48, borderRadius: '50%', fontSize: 22, overflow: 'hidden' }}>
            {!avatarFailed ? (
              <img
                className="ava-img"
                src={avatarUrl(API_BASE, user.telegramId)}
                alt="avatar"
                referrerPolicy="no-referrer"
                onError={() => setAvatarFailed(true)}
              />
            ) : (
              <Icon name="user" />
            )}
          </div>
          <div className="t"><b>@{user.username}</b><small>Уровень {user.level} · {user.rank}</small></div>
          {sub && <span className="badge hot" style={{ background: subCfg(sub.id).color, color: '#000' }}>{subCfg(sub.id).short}</span>}
        </div>
        <div className="bar" style={{ margin: '0 2px 12px' }}><i style={{ width: `${pct}%` }} /></div>
        <div className="card glass pad" style={{ textAlign: 'center', marginBottom: 12 }}>
          <div className="mut" style={{ fontSize: 10 }}>Баланс</div>
          <div className="num" style={{ fontSize: 26, fontWeight: 800 }}>{fmt(user.balance)}</div>
          <div className="mut" style={{ fontSize: 10, letterSpacing: 3 }}>GIFT COIN</div>
        </div>
        <div className="two">
          <div className="card glass"><small>Друзья</small><b>{friendsCountLocal}</b></div>
          <div className="card glass"><small>Кейсов</small><b>{achievements.cases}</b></div>
        </div>
        <div className="menu">
          {MENU.map((m) => (
            <div key={m.title} className="card glass row" onClick={() => (m.to ? go(m.to) : toast('Скоро'))}>
              <div className="bx"><Icon name={m.icon} /></div>
              <div className="t"><b>{m.title}</b></div>
              <span className="mut"><Icon name="back" /></span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
