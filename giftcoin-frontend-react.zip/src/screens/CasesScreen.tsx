import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useNav } from '../store/useNav';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { CASES, STARTER_LEVELS, fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

function StarterCard() {
  const user = useAuthStore((s) => s.user);
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);
  const starter = useLocalStore((s) => s.starter);
  const gatePassed = useLocalStore((s) => s.starterFriendGatePassed);
  const friendsCountLocal = useLocalStore((s) => s.profile.friendsCountLocal);
  const bumpStarter = useLocalStore((s) => s.bumpStarter);
  const passStarterGate = useLocalStore((s) => s.passStarterGate);
  const addVaultItem = useLocalStore((s) => s.addVaultItem);
  const incCases = useLocalStore((s) => s.incCases);

  const lvl = starter.level;
  const cfg = STARTER_LEVELS[lvl - 1];
  const locked = lvl === 1 && !gatePassed && friendsCountLocal < (cfg.requireFriends || 0);

  function open() {
    if (locked) { haptic('error'); toast('Нужно пригласить 2 друзей, чтобы открыть STARTER CASE'); return; }
    if (!user || user.balance < cfg.price) { haptic('error'); toast('Недостаточно коинов'); return; }
    applyCoinDelta(-cfg.price);
    incCases();
    const reward = Math.floor(cfg.price * (0.4 + Math.random() * 2.2));
    applyCoinDelta(reward);
    addVaultItem({ name: `Starter Case · LVL ${lvl}`, emoji: '📦' });
    if (lvl === 1) passStarterGate();
    bumpStarter();
    haptic('success');
    toast(lvl >= 5 ? `Выпало +${fmt(reward)} 📦 · цикл завершён, снова LVL 1!` : `Выпало +${fmt(reward)} 📦 · открыт LVL ${lvl + 1}`);
  }

  return (
    <div
      className="case-item glass"
      style={{ gridColumn: '1/-1', display: 'flex', alignItems: 'center', gap: 14, textAlign: 'left', padding: 12 }}
      onClick={open}
    >
      <div className="ico" style={{ height: 72, width: 72, flex: 'none', margin: 0 }}><Icon name="box" /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <b style={{ display: 'block', fontSize: 13 }}>STARTER CASE · LVL {lvl}/5</b>
        <small style={{ color: 'var(--mut)' }}>{fmt(cfg.price)}{locked ? ' · нужно пригласить 2 друзей' : ' коинов'}</small>
        <div className="sub-dots" style={{ justifyContent: 'flex-start', marginTop: 6 }}>
          {[1, 2, 3, 4, 5].map((n) => <span key={n} className={`dot ${n === lvl ? 'on' : ''}`} />)}
        </div>
      </div>
      <span className={`badge ${locked ? '' : 'hot'}`}>{locked ? <Icon name="users" /> : 'Open'}</span>
    </div>
  );
}

export function CasesScreen() {
  const go = useNav((s) => s.go);
  const user = useAuthStore((s) => s.user);
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);
  const vault = useLocalStore((s) => s.vault);
  const addVaultItem = useLocalStore((s) => s.addVaultItem);
  const incCases = useLocalStore((s) => s.incCases);

  function openCase(id: string) {
    const c = CASES.find((x) => x.id === id);
    if (!c || !user || user.balance < c.price) { haptic('error'); toast('Недостаточно коинов'); return; }
    applyCoinDelta(-c.price);
    incCases();
    const reward = Math.floor(c.price * (0.4 + Math.random() * 2.2));
    applyCoinDelta(reward);
    addVaultItem({ name: c.name, emoji: c.emoji });
    haptic('success');
    toast(`Выпало +${fmt(reward)} ${c.emoji}`);
  }

  return (
    <>
      <Header title="КЕЙСЫ" mode="avatar" />
      <div className="sc">
        <div className="tabs">
          <span className="pill on">Магазин</span>
          <span className="pill" onClick={() => go('vault')}>Хранилище ({vault.length})</span>
        </div>
        <div className="case-grid">
          <StarterCard />
          {CASES.map((c) => (
            <div key={c.id} className="case-item glass" onClick={() => openCase(c.id)}>
              <div className="ico">{c.emoji}</div>
              <b>{c.name}</b>
              <small>{fmt(c.price)} · {c.desc}</small>
            </div>
          ))}
        </div>
        <div className="sec">Как работает STARTER CASE</div>
        <div className="card glass pad" style={{ fontSize: 11, color: 'var(--mut)', lineHeight: 1.6 }}>
          5 уровней подряд: каждый следующий кейс дороже, но открывается только после того, как ты открыл предыдущий. После 5 уровня всё начинается заново с 1-го. Пригласить 2 друзей нужно только один раз — при самой первой попытке открыть STARTER CASE.
        </div>
        <div className="sec">Как работают обычные кейсы</div>
        <div className="card glass pad" style={{ fontSize: 11, color: 'var(--mut)', lineHeight: 1.6 }}>
          Покупай кейс за коины → получай случайный приз. Непонравившиеся можно отложить в хранилище или апгрейдить.
        </div>
      </div>
    </>
  );
}
