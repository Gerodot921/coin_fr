import { Header } from '../components/Header';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { fmt } from '../data/constants';

export function StatsScreen() {
  const user = useAuthStore((s) => s.user);
  const totalTaps = useLocalStore((s) => s.totalTaps);
  const achievements = useLocalStore((s) => s.achievements);
  const vault = useLocalStore((s) => s.vault);
  const friendsCountLocal = useLocalStore((s) => s.profile.friendsCountLocal);

  return (
    <>
      <Header title="СТАТИСТИКА" mode="back" />
      <div className="sc">
        <div className="two">
          <div className="card glass"><small>Всего тапов</small><b className="num">{fmt(totalTaps)}</b></div>
          <div className="card glass"><small>Кейсов открыто</small><b>{achievements.cases}</b></div>
          <div className="card glass"><small>Ранг</small><b>{user?.rank}</b></div>
          <div className="card glass"><small>Рефералов</small><b>{friendsCountLocal}</b></div>
        </div>
        <div className="sec">Призы в хранилище</div>
        <div className="card glass pad" style={{ textAlign: 'center' }}><b style={{ fontSize: 24 }}>{vault.length}</b></div>
      </div>
    </>
  );
}
