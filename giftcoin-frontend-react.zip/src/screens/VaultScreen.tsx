import { Header } from '../components/Header';
import { useLocalStore } from '../store/useLocalStore';
import { toast } from '../components/Toast';

export function VaultScreen() {
  const vault = useLocalStore((s) => s.vault);
  return (
    <>
      <Header title="ХРАНИЛИЩЕ" mode="back" />
      <div className="sc">
        {vault.length ? (
          <div className="vault-grid">
            {vault.map((p, i) => (
              <div key={i} className="vault-item glass" onClick={() => toast(`Приз: ${p.name}`)}>
                <div className="prize-ico">{p.emoji}</div>
                <div style={{ marginTop: 4 }}>{p.name}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty">Хранилище пусто.<br />Открывай кейсы или выигрывай при тапе.</div>
        )}
        <div className="sec">Действия</div>
        <div className="card glass pad" style={{ fontSize: 11, color: 'var(--mut)', lineHeight: 1.6 }}>
          Призы можно апгрейдить в мини-игре или оставить до вывода.
        </div>
      </div>
    </>
  );
}
