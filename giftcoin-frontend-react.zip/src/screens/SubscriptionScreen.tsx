import { useRef, useState } from 'react';
import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { SUBSCRIPTIONS, fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

export function SubscriptionScreen() {
  const [idx, setIdx] = useState(0);
  const user = useAuthStore((s) => s.user);
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);
  const active = useLocalStore((s) => s.subscription);
  const setSubscription = useLocalStore((s) => s.setSubscription);
  const touchX = useRef<number | null>(null);

  const s = SUBSCRIPTIONS[idx];
  const isThis = active && active.id === s.id;
  const blocked = active && active.id !== s.id;

  function nav(dir: number) {
    setIdx((i) => (i + dir + SUBSCRIPTIONS.length) % SUBSCRIPTIONS.length);
  }

  function buy() {
    if (active) {
      toast(isThis ? 'Подписка уже активна' : `Сначала дождитесь окончания подписки ${SUBSCRIPTIONS.find((x) => x.id === active.id)!.short}`);
      return;
    }
    if (!user || user.balance < s.price) { toast(`Нужно ${fmt(s.price)} коинов`); return; }
    applyCoinDelta(-s.price);
    setSubscription({ id: s.id, clicksLeft: s.clicks, clickCount: 0 });
    haptic('success');
    toast(`${s.name} активирован!`);
  }

  let btnLabel: string;
  if (isThis) btnLabel = `Активна ✓ · осталось ${fmt(active!.clicksLeft)} кликов`;
  else if (blocked) btnLabel = `Уже активна ${SUBSCRIPTIONS.find((x) => x.id === active!.id)!.short}`;
  else btnLabel = s.price > 0 ? `Купить ${s.short} · ${fmt(s.price)}` : `Активировать ${s.short} · Бесплатно`;

  return (
    <>
      <Header title="ПОДПИСКИ" mode="back" />
      <div className="sc">
        <div
          className="sub-hero glass"
          onTouchStart={(e) => { touchX.current = e.touches[0].clientX; }}
          onTouchEnd={(e) => {
            if (touchX.current === null) return;
            const dx = e.changedTouches[0].clientX - touchX.current;
            touchX.current = null;
            if (Math.abs(dx) > 40) nav(dx < 0 ? 1 : -1);
          }}
        >
          <div className="sub-arrow left" onClick={() => nav(-1)}><Icon name="back" /></div>
          <div style={{ fontSize: 36, marginBottom: 8, color: s.color }}><Icon name="crown" /></div>
          <h3>{s.name}</h3>
          <p>{s.desc}</p>
          <div className="sub-dots">{SUBSCRIPTIONS.map((_, i) => <span key={i} className={`dot ${i === idx ? 'on' : ''}`} />)}</div>
          <div className="sub-arrow right" onClick={() => nav(1)}><Icon name="back" /></div>
        </div>
        {s.features.map((f) => (
          <div key={f} className="sub-feat"><span className="ck"><Icon name="check" /></span><span style={{ fontSize: 12 }}>{f}</span></div>
        ))}
        {isThis && (
          <div className="card glass pad" style={{ marginTop: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--mut)', marginBottom: 6 }}>
              <span>Прогресс подписки</span><span className="num">{fmt(active!.clicksLeft)} / {fmt(s.clicks)}</span>
            </div>
            <div className="bar"><i style={{ width: `${Math.round((active!.clicksLeft / s.clicks) * 100)}%` }} /></div>
          </div>
        )}
        <button className="full w" disabled={!!isThis || !!blocked} onClick={buy}>{btnLabel}</button>
        <button className="full g" onClick={() => toast('Скоро')}>Купить за реал (скоро)</button>
      </div>
    </>
  );
}
