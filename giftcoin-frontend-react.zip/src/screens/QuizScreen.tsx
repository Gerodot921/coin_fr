import { useState } from 'react';
import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { QUIZ, fmt } from '../data/constants';

export function QuizScreen() {
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState<number | null>(null);

  const q = QUIZ[idx];

  function answer(i: number) {
    if (answered !== null) return;
    setAnswered(i);
    if (i === q.a) setScore((s) => s + 1);
    setTimeout(() => { setIdx((n) => n + 1); setAnswered(null); }, 800);
  }

  if (!q) {
    return (
      <>
        <Header title="ВИКТОРИНА" mode="back" />
        <div className="sc">
          <div className="card glass pad" style={{ textAlign: 'center', padding: 30 }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}><Icon name="trophy" /></div>
            <b style={{ fontSize: 16 }}>Результат: {score}/{QUIZ.length}</b>
            <p className="mut" style={{ marginTop: 8, fontSize: 12 }}>Награда: +{fmt(score * 50000)} коинов</p>
            <button className="full w" onClick={() => { setIdx(0); setScore(0); }}>Играть снова</button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Header title="ВИКТОРИНА" mode="back" />
      <div className="sc">
        <div className="card glass pad">
          <div className="mut" style={{ fontSize: 10, marginBottom: 8 }}>Вопрос {idx + 1}/{QUIZ.length}</div>
          <div className="quiz-q">{q.q}</div>
          {q.opts.map((o, i) => {
            let cls = 'quiz-opt glass';
            if (answered !== null) cls += i === q.a ? ' correct' : ' wrong';
            return (
              <button key={i} className={cls} disabled={answered !== null} onClick={() => answer(i)}>{o}</button>
            );
          })}
        </div>
      </div>
    </>
  );
}
