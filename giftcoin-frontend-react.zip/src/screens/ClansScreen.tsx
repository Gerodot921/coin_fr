import { Header } from '../components/Header';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

export function ClansScreen() {
  const user = useAuthStore((s) => s.user);
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);
  const clan = useLocalStore((s) => s.clan);
  const setClan = useLocalStore((s) => s.setClan);

  if (clan) {
    return (
      <>
        <Header title="КЛАН" mode="back" />
        <div className="sc">
          <div className="clan-banner glass">
            <div className="clan-logo">{clan.logo}</div>
            <b style={{ fontSize: 16 }}>{clan.name}</b>
            <p className="mut" style={{ fontSize: 11, marginTop: 4 }}>{clan.members}/100 участников</p>
          </div>
          <div className="two">
            <div className="card glass"><small>Рейтинг</small><b>#{clan.rank}</b></div>
            <div className="card glass"><small>Тапов за войну</small><b className="num">{fmt(clan.warTaps)}</b></div>
          </div>
          <div className="sec">Клановая война</div>
          <div className="card glass pad">
            <p style={{ fontSize: 12, color: 'var(--mut)', lineHeight: 1.5, marginBottom: 10 }}>Осталось 18ч · Ваш клан на 3 месте</p>
            <div className="bar"><i style={{ width: '65%' }} /></div>
          </div>
          <button className="full g" onClick={() => { setClan(null); toast('Вы покинули клан'); }}>Покинуть клан</button>
        </div>
      </>
    );
  }

  return (
    <>
      <Header title="КЛАНЫ" mode="back" />
      <div className="sc">
        <div className="card glass pad" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 40, marginBottom: 10 }}>⚔️</div>
          <b>Создай или вступи в клан</b>
          <p className="mut" style={{ fontSize: 11, marginTop: 8, lineHeight: 1.5 }}>Войны · бонусы x2 · эксклюзивные призы · до 100 участников</p>
        </div>
        <button
          className="full w"
          onClick={() => {
            if (!user || user.balance < 50000000) { toast('Нужно 50,000,000'); return; }
            applyCoinDelta(-50000000);
            setClan({ name: 'My Clan', logo: '🛡️', members: 1, rank: 99, warTaps: 0 });
            haptic('success'); toast('Клан создан!');
          }}
        >
          Создать клан · 50,000,000
        </button>
        <button
          className="full g"
          onClick={() => { setClan({ name: 'Alpha Tappers', logo: '⚔️', members: 87, rank: 3, warTaps: 1250000 }); haptic('success'); toast('Вы вступили в клан!'); }}
        >
          Вступить бесплатно
        </button>
        <div className="sec">Топ кланов</div>
        {['Alpha Tappers', 'Coin Legion', 'Gift Warriors'].map((n, i) => (
          <div key={n} className="card glass row">
            <span className="rk">{i + 1}</span>
            <div className="t"><b>{n}</b><small>{fmt((3 - i) * 50000000)} тапов</small></div>
          </div>
        ))}
      </div>
    </>
  );
}
