import { Header } from '../components/Header';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { fmt, BOT_USERNAME } from '../data/constants';
import { toast } from '../components/Toast';
import { openTelegramLink, haptic } from '../telegram';

export function FriendsScreen() {
  const user = useAuthStore((s) => s.user);
  const friendsCountLocal = useLocalStore((s) => s.profile.friendsCountLocal);

  function invite() {
    haptic('light');
    const link = `https://t.me/share/url?url=${encodeURIComponent(`https://t.me/${BOT_USERNAME}?startapp=${user?.telegramId || ''}`)}&text=${encodeURIComponent('GIFT COIN — тапай, зарабатывай, выигрывай!')}`;
    openTelegramLink(link);
    toast('Ссылка отправлена');
  }

  return (
    <>
      <Header title="РЕФЕРАЛЫ" mode="back" />
      <div className="sc">
        <div className="three">
          <div className="card glass"><small>1 ур.</small><b>15%</b></div>
          <div className="card glass"><small>2 ур.</small><b>5%</b></div>
          <div className="card glass"><small>3 ур.</small><b>3%</b></div>
        </div>
        <div className="two">
          <div className="card glass"><small>Друзей</small><b>{friendsCountLocal}</b></div>
          <div className="card glass"><small>Заработано</small><b className="num">{fmt(0)}</b></div>
        </div>
        <button className="full w" onClick={invite}>Пригласить друга · +100,000</button>
        <div className="sec">Ваши рефералы</div>
        <div className="empty">
          Список рефералов появится, как только бэкенд начнёт начислять бонусы за приглашения (пока `/users/auth` не обрабатывает start_param).
        </div>
      </div>
    </>
  );
}
