import { useState } from 'react';
import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useNav } from '../store/useNav';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { DAILY_TASKS, PROJECT_TASKS, AD_TASKS, TaskDef, fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic, openTelegramLink } from '../telegram';

type Tab = 'daily' | 'project' | 'ads';

export function TasksScreen() {
  const [tab, setTab] = useState<Tab>('daily');
  const go = useNav((s) => s.go);
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);
  const profile = useLocalStore((s) => s.profile);
  const totalTaps = useLocalStore((s) => s.totalTaps);
  const claimTask = useLocalStore((s) => s.claimTask);
  const claimDailyLogin = useLocalStore((s) => s.claimDailyLogin);

  const today = new Date().toDateString();
  const list: TaskDef[] = tab === 'daily' ? DAILY_TASKS : tab === 'project' ? PROJECT_TASKS : AD_TASKS;

  function claim(t: TaskDef) {
    // Tasks aren't wired to a backend endpoint yet — reward is applied
    // client-side against the real balance, same shadow-state caveat as
    // cases/wheel/quiz. Next refreshBalance() call reconciles with the
    // server once a matching /tasks endpoint exists.
    if (t.action === 'link' && t.meta) openTelegramLink(`https://${t.meta}`);
    if (t.kind === 'daily' && t.id === 'daily_login') {
      if (new Date(profile.lastLoginTs).toDateString() === today) return;
      claimDailyLogin();
    } else if (t.kind === 'once') {
      if (profile.tasksClaimed.includes(t.id)) return;
      claimTask(t.id);
    }
    applyCoinDelta(t.reward);
    haptic('success');
    toast(`+${fmt(t.reward)}`);
  }

  function right(t: TaskDef) {
    const claimed = t.kind === 'once' && profile.tasksClaimed.includes(t.id);
    const dailyDone = t.kind === 'daily' && t.id === 'daily_login' && new Date(profile.lastLoginTs).toDateString() === today;
    if (claimed || dailyDone) return <span><Icon name="check" /></span>;
    if (t.action === 'progress') return <span className="mut" style={{ fontSize: 10 }}>{Math.min(1000, totalTaps)}/1000</span>;
    if (t.action === 'video') return <button className="btnd" onClick={() => claim(t)}>Смотреть</button>;
    return <button className="btnw" onClick={() => claim(t)}>{t.action === 'link' ? 'Go' : 'Забрать'}</button>;
  }

  return (
    <>
      <Header title="ЗАДАНИЯ" mode="avatar" />
      <div className="sc">
        <div className="tabs">
          <span className={`pill ${tab === 'daily' ? 'on' : ''}`} onClick={() => setTab('daily')}>Ежедневные</span>
          <span className={`pill ${tab === 'project' ? 'on' : ''}`} onClick={() => setTab('project')}>Проект</span>
          <span className={`pill ${tab === 'ads' ? 'on' : ''}`} onClick={() => setTab('ads')}>Рекламодатели</span>
          <span className="pill" onClick={() => go('achievements')}>Ачивки</span>
        </div>
        {list.map((t) => (
          <div key={t.id} className="card glass row">
            <div className="bx"><Icon name="clip" /></div>
            <div className="t"><b>{t.title}</b><small>+{fmt(t.reward)}</small></div>
            {right(t)}
          </div>
        ))}
      </div>
    </>
  );
}
