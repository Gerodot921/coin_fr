import { useState } from 'react';
import { Header } from '../components/Header';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { WHEEL_SEGMENTS, WHEEL_REWARDS, fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

export function WheelScreen() {
  const user = useAuthStore((s) => s.user);
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);
  const wheelLast = useLocalStore((s) => s.wheelLast);
  const spinWheel = useLocalStore((s) => s.spinWheel);
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);

  const free = Date.now() - wheelLast > 86400000;
  const colors = WHEEL_SEGMENTS.map((_, i) => (i % 2 ? '#1a1a1a' : '#2a2a2a'));
  const gradient = WHEEL_SEGMENTS.map((_, i) => `${colors[i]} ${i * (360 / WHEEL_SEGMENTS.length)}deg ${(i + 1) * (360 / WHEEL_SEGMENTS.length)}deg`).join(',');

  function spin(paid: boolean) {
    if (spinning) return;
    if (!paid && !free) return;
    if (paid) {
      if (!user || user.balance < 100000) { toast('Нужно 100,000'); return; }
      applyCoinDelta(-100000);
    } else {
      spinWheel();
    }
    setSpinning(true);
    const extra = 1800 + Math.random() * 1800;
    setAngle((a) => a + extra);
    setTimeout(() => {
      setSpinning(false);
      const win = WHEEL_REWARDS[Math.floor(Math.random() * WHEEL_REWARDS.length)];
      applyCoinDelta(win);
      haptic('success');
      toast(`+${fmt(win)}!`);
    }, 4000);
  }

  return (
    <>
      <Header title="КОЛЕСО" mode="back" />
      <div className="sc">
        <div className="wheel-box">
          <div className="wheel-pointer" />
          <div className="wheel" style={{ background: `conic-gradient(${gradient})`, transform: `rotate(${angle}deg)` }}>
            <div style={{ position: 'absolute', inset: '30%', borderRadius: '50%', background: '#000', border: '2px solid rgba(255,255,255,.2)', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700 }}>SPIN</div>
          </div>
        </div>
        <button className="full w" disabled={!free || spinning} onClick={() => spin(false)}>
          {free ? 'Крутить бесплатно' : `Следующий спин через ${Math.ceil((86400000 - (Date.now() - wheelLast)) / 3600000)}ч`}
        </button>
        <button className="full g" disabled={spinning} onClick={() => spin(true)}>Крутить за 100,000</button>
      </div>
    </>
  );
}
