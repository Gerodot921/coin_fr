import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { BOOSTS, boostCost, fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

export function BoostScreen() {
  const user = useAuthStore((s) => s.user);
  const boosts = useLocalStore((s) => s.profile.boosts);

  function buy() {
    // Boosters aren't wired to the backend yet — buying one client-side
    // would spend from a balance the server doesn't know about, so this
    // stays disabled until a matching /boost endpoint exists.
    haptic('light');
    toast('Бустеры скоро подключим к серверу');
  }

  return (
    <>
      <Header title="БУСТЕРЫ" mode="back" />
      <div className="sc">
        {BOOSTS.map((b) => {
          const lvl = boosts[b.id] || 0;
          const cost = boostCost(b, lvl);
          const dis = !user || user.balance < cost;
          return (
            <div key={b.id} className="card glass row">
              <div className="bx"><Icon name={b.icon} /></div>
              <div className="t"><b>{b.name}</b><small>{b.desc}{lvl ? ` · ур.${lvl}` : ''}</small></div>
              <button className="btnw" style={dis ? { opacity: 0.4 } : undefined} onClick={buy}>{fmt(cost)}</button>
            </div>
          );
        })}
      </div>
    </>
  );
}
