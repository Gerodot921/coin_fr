import { Header } from '../components/Header';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

export function DailyScreen() {
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);
  const totalTaps = useLocalStore((s) => s.totalTaps);

  const day = Math.min(7, Math.floor(totalTaps / 500) + 1);
  const reward = 50000 + day * 25000;

  return (
    <>
      <Header title="ЕЖЕДНЕВНАЯ" mode="back" />
      <div className="sc">
        <div className="card glass pad" style={{ textAlign: 'center', padding: 28 }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🎁</div>
          <b style={{ fontSize: 15 }}>День {day}</b>
          <p className="mut" style={{ fontSize: 12, margin: '10px 0' }}>+{fmt(reward)} коинов</p>
          <button
            className="full w"
            onClick={() => { applyCoinDelta(reward); haptic('success'); toast(`+${fmt(reward)}`); }}
          >
            Забрать награду
          </button>
        </div>
      </div>
    </>
  );
}
