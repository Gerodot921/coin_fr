import { Header } from '../components/Header';
import { useAuthStore } from '../store/useAuthStore';
import { useLocalStore } from '../store/useLocalStore';
import { fmt } from '../data/constants';

export function AchievementsScreen() {
  const user = useAuthStore((s) => s.user);
  const a = useLocalStore((s) => s.achievements);
  const clan = useLocalStore((s) => s.clan);

  const items = [
    { id: 'taps', title: '1000 тапов', cur: a.taps, max: 1000, reward: 100000 },
    { id: 'cases', title: '10 кейсов', cur: a.cases, max: 10, reward: 500000 },
    { id: 'refs', title: '10 рефералов', cur: a.refs, max: 10, reward: 1000000 },
    { id: 'clan', title: 'Вступи в клан', cur: clan ? 1 : 0, max: 1, reward: 200000 },
  ];

  return (
    <>
      <Header title="ДОСТИЖЕНИЯ" mode="back" />
      <div className="sc">
        {items.map((it) => {
          const pct = Math.min(100, Math.round((it.cur / it.max) * 100));
          return (
            <div key={it.id} className="card glass pad">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <b style={{ fontSize: 13 }}>{it.title}</b>
                <span className="mut" style={{ fontSize: 10 }}>{Math.min(it.cur, it.max)}/{it.max}</span>
              </div>
              <div className="bar"><i style={{ width: `${pct}%` }} /></div>
              <small className="mut" style={{ display: 'block', marginTop: 6 }}>Награда: +{fmt(it.reward)}</small>
            </div>
          );
        })}
        <div className="sec">VIP уровни</div>
        <div className="vip-row">
          {['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'].map((v, i) => (
            <span key={v} className={`vip-badge ${user && user.level > i + 2 ? 'active' : ''}`}>{v}</span>
          ))}
        </div>
      </div>
    </>
  );
}
