import { Header } from '../components/Header';
import { Icon } from '../components/Icons';

export function StakingScreen() {
  return (
    <>
      <Header title="СТЕЙКИНГ" mode="back" />
      <div className="sc">
        <div className="card glass pad" style={{ textAlign: 'center', padding: 32 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}><Icon name="vault" /></div>
          <b>Стейкинг коинов</b>
          <p className="mut" style={{ fontSize: 12, marginTop: 10, lineHeight: 1.6 }}>
            Застейкай коины для пассивного дохода. Увеличение % со временем. Досрочный вывод — со штрафом.
          </p>
          <span className="badge" style={{ marginTop: 16, display: 'inline-block' }}>Скоро</span>
        </div>
      </div>
    </>
  );
}
