import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useNav } from '../store/useNav';

const ITEMS: { to: any; icon: string; title: string; desc: string; badge: string }[] = [
  { to: 'upgrader', icon: 'up', title: 'Апгрейдер', desc: 'Улучши приз или потеряй', badge: '50/50' },
  { to: 'wheel', icon: 'wheel', title: 'Колесо фортуны', desc: 'Бесплатно раз в 24ч', badge: 'Spin' },
  { to: 'quiz', icon: 'quiz', title: 'Викторина', desc: 'Вопросы про крипто', badge: '+награда' },
  { to: 'leaderboard', icon: 'trophy', title: 'Лидерборд', desc: 'Топ таперов и рефералов', badge: 'TOP' },
];

export function GamesHubScreen() {
  const go = useNav((s) => s.go);
  return (
    <>
      <Header title="ИГРЫ" mode="avatar" />
      <div className="sc">
        <div className="sec">Мини-игры</div>
        {ITEMS.map((it) => (
          <div key={it.to} className="card glass row menu" onClick={() => go(it.to)}>
            <div className="bx"><Icon name={it.icon} /></div>
            <div className="t"><b>{it.title}</b><small>{it.desc}</small></div>
            <span className={`badge ${it.badge === '50/50' ? 'hot' : ''}`}>{it.badge}</span>
          </div>
        ))}
        <div className="sec">Клановые войны</div>
        <div className="card glass pad">
          <p style={{ fontSize: 12, lineHeight: 1.5, color: 'var(--mut)' }}>
            Соревнование между кланами — кто больше прокликает за 24–48 часов. Победители получают x2 коины и эксклюзивные призы.
          </p>
          <button className="full g" onClick={() => go('clans')}>Перейти к кланам</button>
        </div>
      </div>
    </>
  );
}
