import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { SHOP_PACKS, fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

export function ShopScreen() {
  return (
    <>
      <Header title="МАГАЗИН" mode="back" />
      <div className="sc">
        {SHOP_PACKS.map((p) => (
          <div key={p.id} className="card glass row">
            <div className="bx"><Icon name="gift" /></div>
            <div className="t"><b>{p.name}</b><small>{fmt(p.amount)} коинов</small></div>
            <button className="btnw" onClick={() => { haptic('warning'); toast('Оплата скоро'); }}>{p.price}</button>
          </div>
        ))}
        <div className="mut" style={{ fontSize: 10, textAlign: 'center', marginTop: 14 }}>Оплата через Telegram Stars / TON</div>
      </div>
    </>
  );
}
