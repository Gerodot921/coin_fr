import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { useAuthStore } from '../store/useAuthStore';
import { fmt } from '../data/constants';
import { toast } from '../components/Toast';
import { haptic } from '../telegram';

const COST = 50000;

export function UpgraderScreen() {
  const user = useAuthStore((s) => s.user);
  const applyCoinDelta = useAuthStore((s) => s.applyCoinDelta);

  function play() {
    if (!user || user.balance < COST) { toast('Недостаточно коинов'); return; }
    applyCoinDelta(-COST);
    if (Math.random() < 0.5) {
      applyCoinDelta(COST * 2);
      haptic('success'); toast(`Успех! +${fmt(COST * 2)}`);
    } else {
      haptic('error'); toast('Ставка потеряна…');
    }
  }

  return (
    <>
      <Header title="АПГРЕЙДЕР" mode="back" />
      <div className="sc">
        <div className="card glass upgrade-zone">
          <div className="slot"><Icon name="gift" /></div>
          <div className="mut" style={{ fontSize: 11 }}>Поставь {fmt(COST)} коинов</div>
          <div className="upgrade-arrows">↑ ↑ ↑</div>
          <div style={{ fontSize: 11, color: 'var(--mut)' }}>50% удвоение · 50% потеря ставки</div>
        </div>
        <button className="full w" onClick={play}>Апгрейд · {fmt(COST)}</button>
        <div className="sec">Правила</div>
        <div className="card glass pad" style={{ fontSize: 11, color: 'var(--mut)', lineHeight: 1.6 }}>
          Ставь коины на удвоение. При успехе — ставка удваивается. При провале — ставка теряется. Можно играть несколько раз подряд.
        </div>
      </div>
    </>
  );
}
