import { useEffect, useState } from 'react';
import { Header } from '../components/Header';
import { Icon } from '../components/Icons';
import { api, LeaderboardRow } from '../api';
import { fmt } from '../data/constants';

function rowName(r: LeaderboardRow) {
  return r.name || r.first_name || (r.username ? `@${r.username}` : `Игрок #${r.id}`);
}

export function LeaderboardScreen() {
  const [rows, setRows] = useState<LeaderboardRow[]>([]);
  const [state, setState] = useState<'loading' | 'ok' | 'error'>('loading');

  useEffect(() => {
    let alive = true;
    api.leaderboard()
      .then((r) => { if (alive) { setRows(r); setState('ok'); } })
      .catch(() => { if (alive) setState('error'); });
    return () => { alive = false; };
  }, []);

  return (
    <>
      <Header title="РЕЙТИНГ" mode="back" />
      <div className="sc">
        <p className="mut" style={{ fontSize: 11, marginBottom: 10 }}>Текущий рейтинг backend строится по звёздам ⭐</p>
        {state === 'loading' && <div className="mut" style={{ textAlign: 'center', padding: 20 }}>Загрузка…</div>}
        {state === 'error' && <div className="empty">Не удалось загрузить рейтинг</div>}
        {state === 'ok' && rows.map((r, i) => (
          <div key={r.id} className="card glass row">
            <span className="rk">{i + 1}</span>
            <div className="bx" style={{ fontSize: 12 }}><Icon name={i < 3 ? 'medal' : 'user'} /></div>
            <div className="t"><b>{rowName(r)}</b></div>
            <b className="num">{fmt(Number(r.stars ?? r.coins ?? 0))}</b>
          </div>
        ))}
      </div>
    </>
  );
}
