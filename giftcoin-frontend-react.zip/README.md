# GIFT COIN — Mini App (React/Vite rewrite)

React + TypeScript + Zustand frontend for the Gift Coin FastAPI backend
(`giftcoin-back`). This replaces the old single-file `gift-coin-front.html`
vanilla-JS app — same feature set, same black glass-card design, new stack.

## Backend contract

Wired to the FastAPI routes that actually exist today:

- `POST /api/v1/users/auth`
- `GET /api/v1/balance/`
- `POST /api/v1/click/`
- `GET /api/v1/rating/`
- `GET /api/v1/utils/health-check/`

Every request sends the raw Telegram `initData` in `X-Telegram-Init-Data`.

## What's real vs. shadow state

Only balance/coins/stars come from the server. Everything the backend
doesn't own yet lives in `zustand/persist` (localStorage) exactly like it
did in the old `gift-coin-front.html` — cases, STARTER CASE, wheel, quiz,
clans, subscriptions (PRO/Elite), boosters, tasks/achievements, vault,
staking. Each of those screens has a comment in the code marking it as
shadow state so it's obvious what still needs a backend endpoint.

Known backend gaps (unchanged from the skeleton's original README):

- No upgrade/boost purchase endpoint — Boosters screen stays disabled with a toast.
- `/rating/` ranks by `stars`, not `coins` — Leaderboard screen labels this explicitly.
- `/users/auth` ignores `start_param` — referral link works (uses `?startapp=`), but reward tracking is local-only until the backend adds referral logic.
- `/click/` is one click per request — the tap screen updates locally first (instant feedback) and flushes clicks to the backend in the background, queued to max 3 in-flight requests.

## Local setup

```bash
npm install
cp .env.example .env
npm run dev
```

For production, set:

```text
VITE_API_URL=https://api.richmachine.ru/api/v1
VITE_BOT_USERNAME=GlFT_Coin_bot
```

## Project structure

```text
src/
  api.ts                  axios client for the FastAPI endpoints above
  telegram.ts              Telegram WebApp SDK helpers (initData, haptics, avatar URL)
  data/constants.ts         game constants ported 1:1 from the old front (cases, ranks, quiz, subscriptions...)
  types.ts                  shared TS types for the local shadow state
  store/
    useAuthStore.ts          backend user + balance (source of truth for coins/stars)
    useLocalStore.ts          persisted shadow state (energy, vault, subscriptions, clans, boosts, tasks...)
    useNav.ts                  screen router (root tab + current screen, mirrors old go()/back())
  hooks/useTap.ts            tap economy: energy gate, optimistic UI, background /click/ flush
  components/                Header, BottomNav, Icon sprite, Toast
  screens/                    one file per screen (19 screens, same set as the old front)
  styles/index.css            ported glass-card CSS
```

## Deploy (Cloudflare Pages)

The frontend hosting domain moved from Vercel to Cloudflare Pages, which
changes how the app talks to the API — there is no more same-origin rewrite
proxy in front of it (the old `vercel.json` `rewrites` are gone). The app now
calls the FastAPI backend **directly, cross-origin**, using the full URL from
`VITE_API_URL`. This makes the frontend's hosting domain irrelevant to the
API logic — same build works from any Cloudflare Pages domain, a custom
domain, or a preview URL.

Setup:

1. Connect the repo in the Cloudflare Pages dashboard (or `wrangler pages deploy`).
2. Build command: `npm run build`. Output directory: `dist`.
3. Project → Settings → Environment variables: set `VITE_API_URL` and
   `VITE_BOT_USERNAME` for both Production and Preview.
4. `public/_redirects` (`/* /index.html 200`) is already in the repo — Pages
   picks it up automatically and serves `index.html` for every route, since
   this is a client-side-routed SPA.

### Backend CORS — required now

Because requests are cross-origin, the FastAPI backend's `CORS_ORIGIN` must
explicitly allow the Cloudflare Pages origin(s):

- the production domain (custom domain or `<project>.pages.dev`)
- `https://*.<project>.pages.dev` for preview deployments, if FastAPI's CORS
  middleware supports a wildcard/regex origin — otherwise previews will get
  CORS errors and only the production domain will work

No cookies are sent (auth is the `X-Telegram-Init-Data` header), so
`Access-Control-Allow-Credentials` isn't needed — a plain origin allow-list
is enough. The backend must also allow the `X-Telegram-Init-Data` request
header and `POST`/`GET` methods in its CORS config, and answer `OPTIONS`
preflight requests (browsers will preflight the POST calls because of that
custom header).

Avatar images (`<img src="{API_BASE}/avatar/{id}">`) aren't affected by CORS
— image loads aren't subject to the same-origin policy — so no extra config
is needed there.

## Architecture

```text
Telegram Mini App
       |
       | X-Telegram-Init-Data
       v
React / Zustand  (Vite build -> static dist/, hosted on Cloudflare Pages)
       |
       | direct cross-origin fetch (X-Telegram-Init-Data header, CORS)
       v
FastAPI /api/v1
       |
       v
SQLAlchemy async
       |
       v
PostgreSQL
```
